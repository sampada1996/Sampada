"""alumnidb URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from django.conf.urls import url
from django.conf.urls import include
from alumniapp import views
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('admin/', admin.site.urls),
    url('^$', views.index, name='index'),
    url('^login/$',views.login, name='login'),
    url('^alumni_reg/$', views.alumni_reg, name='alumni_reg'),
    url('^alumni_home/$', views.alumni_home, name='alumni_home'),
    url('^admin_home/$', views.admin_home, name='admin_home'),
    url('^employment_info/$', views.employment_info, name='employment_info'),
    url('^employment_info_a/$', views.employment_info_a, name='employment_info_a'),
    url('^employment_info_view/$', views.employment_info_view, name='employment_info_view'),
    url('^employment_info_view_a/$', views.employment_info_view_a, name='employment_info_view_a'),
    url('^employ_del/$', views.employ_del, name='employ_del'),
    url('^employ_update/$', views.employ_update, name='employ_update'),
    url('^employ_db/$', views.employ_db, name='employ_db'),
    url('^employ_del_a/$', views.employ_del_a, name='employ_del_a'),
    url('^employ_update_a/$', views.employ_update_a, name='employ_update_a'),
    url('^employ_db_a/$', views.employ_db_a, name='employ_db_a'), \
    url('^search_alumni/$', views.search_alumni, name='search_alumni'),
    url('^alumni_del/$', views.alumni_del, name='alumni_del'),
    url('^alumni_update/$', views.alumni_update, name='alumni_update'),
    url('^alumni_db/$', views.alumni_db, name='alumni_db'),
    url('^alumni_view/$', views.alumni_view, name='alumni_view'),
    url('^edit_alumni/$', views.edit_alumni, name='edit_alumni'),
    url('^alumni_db_a/$', views.alumni_db_a, name='alumni_db_a'),
    url('^add_event/$', views.add_event, name='add_event'),
    url('^event_view/$', views.event_view, name='event_view'),
    url('^event_view_a/$', views.event_view_a, name='event_view_a'),
    url('^chapter_wise_view/$', views.chapter_wise_view, name='chapter_wise_view'),
    url('^chapter/$', views.chapter, name='chapter'),
    url('^chapter_blore/$', views.chapter_blore, name='chapter_blore'),
    url('^chapter_belgaum/$', views.chapter_belgaum, name='chapter_belgaum'),
    url('^chapter_bvb/$', views.chapter_bvb, name='chapter_bvb'),
    url('^chapter_pune/$', views.chapter_pune, name='chapter_pune'),
    url('^forgotpass/$', views.forgotpass, name='forgotpass'),
    url('^send_mail/(?P<pk>\d+)/$', views.send_mail, name='send_mail'),
    url('^send_mail_alumni/$', views.send_mail_alumni, name='send_mail_alumni'),
    url('^gallery/$', views.gallery, name='gallery'),
]


if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)