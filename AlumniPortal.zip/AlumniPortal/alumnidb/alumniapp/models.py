from django.db import models

class AlumniRegistration(models.Model):
    logId = models.CharField(max_length=200,null=True,blank=True)
    password = models.CharField(max_length=50)
    fname = models.EmailField(max_length=100)
    mname = models.CharField(max_length=100)
    lname = models.CharField(max_length=100)
    gender = models.CharField(max_length=100)
    dob = models.CharField(max_length=100)
    email = models.CharField(max_length=100,null=True,blank=True)
    landlineno = models.CharField(max_length=100)
    mobileno = models.CharField(max_length=100)
    alumni_chapter = models.CharField(max_length=100)
    address = models.CharField(max_length=100)
    street = models.CharField(max_length=100)
    city = models.CharField(max_length=100)
    pincode = models.CharField(max_length=100)
    country = models.CharField(max_length=100)
    state = models.CharField(max_length=100,null=True,blank=True)
    file = models.FileField(upload_to='documents/',null=True,blank=True)


class UserLogin(models.Model):
    username = models.CharField(max_length=200)
    password = models.CharField(max_length=50)
    utype = models.CharField(max_length=50)


class EmploymentDetails(models.Model):
    username = models.CharField(max_length=200)
    organization = models.CharField(max_length=200)
    designation = models.CharField(max_length=200)
    address = models.CharField(max_length=200)
    country = models.CharField(max_length=200)
    pincode = models.CharField(max_length=200)
    expertise_in = models.CharField(max_length=200)
    achievement = models.CharField(max_length=200)
    course = models.CharField(max_length=200)
    branch = models.CharField(max_length=200)
    passing_year = models.CharField(max_length=200)


class AddEvent(models.Model):
    chapter = models.CharField(max_length=200,null=True,blank=True)
    eventdate = models.CharField(max_length=200)
    eventtime = models.CharField(max_length=200)
    eventname = models.CharField(max_length=200)
    venue = models.CharField(max_length=200)
    description = models.CharField(max_length=500)

