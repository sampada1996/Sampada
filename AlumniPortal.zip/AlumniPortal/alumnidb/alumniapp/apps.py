from django.apps import AppConfig


class AlumniappConfig(AppConfig):
    name = 'alumniapp'
