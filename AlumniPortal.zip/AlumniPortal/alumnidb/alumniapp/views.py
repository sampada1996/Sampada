from django.shortcuts import render
from alumnidb.settings import BASE_DIR
from django.core.files.storage import FileSystemStorage
from alumniapp.models import UserLogin
from alumniapp.models import AlumniRegistration
from alumniapp.models import EmploymentDetails
from alumniapp.models import AddEvent
import os
import image
from PIL import Image
import smtplib
def index(request):

    return render(request,'index.html')


def login(request):
    if request.method == "POST":
        username = request.POST.get('t1', '')
        password = request.POST.get('t2', '')
        request.session['username']=username
        #if username=="admin" and password=="admin":
        checklogin = UserLogin.objects.filter(username=username).values()
        for a in checklogin:
            utype = a['utype']
            upass= a['password']
            if(upass == password):

                if(utype == "admin"):

                    return render(request,'admin_home.html',context={'msg':'welcome to admin'})
                if(utype == "alumni"):
                    return render(request, 'alumni_home.html', context={'u': username})
            else:
                return render(request,'login.html',{'msg':'invalid username or password'})

    return render(request,'login.html')


def alumni_reg(request):

    if request.method=="POST" and request.FILES['myfile']:
        logid=request.POST.get('t1','')
        password = request.POST.get('t2', '')
        fname = request.POST.get('t3', '')
        mname = request.POST.get('t4', '')
        lname = request.POST.get('t5', '')
        dob = request.POST.get('t6', '')
        email = request.POST.get('t7', '')
        landline = request.POST.get('t8', '')
        gender = request.POST.get('t9', '')
        mobileno = request.POST.get('t10', '')
        alumni_chapter = request.POST.get('t11', '')
        address = request.POST.get('t12', '')
        street = request.POST.get('t13', '')
        city = request.POST.get('t14', '')
        pincode = request.POST.get('t15', '')
        country = request.POST.get('t16', '')
        state = request.POST.get('t17', '')
        myfile = request.FILES['myfile']
        fs = FileSystemStorage()
        filename = fs.save(myfile.name, myfile)
        uploaded_file_url = fs.url(filename)
        pat = os.path.join(BASE_DIR, '/media/' + filename)
        AlumniRegistration.objects.create(password=password,fname=fname,mname=mname,lname=lname,gender=gender,dob=dob,landlineno=landline,mobileno=mobileno,alumni_chapter=alumni_chapter,address=address,street=street,city=city,pincode=pincode,country=country,state=state,file=myfile,email=email,logId=logid)
        UserLogin.objects.create(username=logid,password=password,utype='alumni')
        return render(request,'index.html',{'msg':'registration has done successfully'})

    return render(request,'alumni_reg.html')



def alumni_home(request):
    return render(request,'alumni_home.html')

def admin_home(request):
    return render(request,'admin_home.html')


def employment_info(request):
    username=request.session['username']
    if request.method=="POST":
        organization = request.POST.get('t1', '')
        designation = request.POST.get('t2', '')
        address = request.POST.get('t3', '')
        country = request.POST.get('t4', '')
        pincode = request.POST.get('t5', '')
        expertise_in = request.POST.get('t6', '')
        achievement = request.POST.get('t7', '')
        course = request.POST.get('t8', '')
        branch = request.POST.get('t9', '')
        passing_year = request.POST.get('t10', '')
        EmploymentDetails.objects.create(username=username,organization=organization,designation=designation,address=address,country=country,pincode=pincode,expertise_in=expertise_in,achievement=achievement,course=course,branch=branch,passing_year=passing_year)
        return render(request,'alumni_home.html',{'u':username})

    return render(request,'employment_info.html')



def employment_info_a(request):
    username=request.session['username']
    if request.method=="POST":
        organization = request.POST.get('t1', '')
        designation = request.POST.get('t2', '')
        address = request.POST.get('t3', '')
        country = request.POST.get('t4', '')
        pincode = request.POST.get('t5', '')
        expertise_in = request.POST.get('t6', '')
        achievement = request.POST.get('t7', '')
        course = request.POST.get('t8', '')
        branch = request.POST.get('t9', '')
        passing_year = request.POST.get('t10', '')
        EmploymentDetails.objects.create(username=username,organization=organization,designation=designation,address=address,country=country,pincode=pincode,expertise_in=expertise_in,achievement=achievement,course=course,branch=branch,passing_year=passing_year)
        return render(request,'admin_home.html',{'u':username})

    return render(request,'employment_info_a.html')





def employment_info_view(request):
    username=request.session['username']
    userdict=EmploymentDetails.objects.filter(username=username).values()
    return render(request,'employment_info_view.html',{'userdict':userdict})

def employment_info_view_a(request):
    username=request.session['username']
    userdict=EmploymentDetails.objects.all()
    return render(request,'employment_info_view_a.html',{'userdict':userdict})

def employ_del(request):
    if request.method=="POST":
        id=request.POST.get('id')
        udata=EmploymentDetails.objects.get(id=id)
        udata.delete()
        userdict=EmploymentDetails.objects.all()
        return render(request,'employment_info_view.html',{'userdict':userdict})

def employ_update(request):
    if request.method=="POST":
        id=request.POST.get('id')
        userdict=EmploymentDetails.objects.filter(id=id).values()
        return render(request,'employ_edit.html',{'userdict':userdict})

def employ_db(request):
    if request.method=="POST":
        id=request.POST.get('id')
        organization = request.POST.get('t1', '')
        designation = request.POST.get('t2', '')
        address = request.POST.get('t3', '')
        country = request.POST.get('t4', '')
        pincode = request.POST.get('t5', '')
        expertise_in = request.POST.get('t6', '')
        achievement = request.POST.get('t7', '')
        course = request.POST.get('t8', '')
        branch = request.POST.get('t9', '')
        passing_year = request.POST.get('t10', '')
        EmploymentDetails.objects.filter(id=id).update(organization=organization, designation=designation,address=address, country=country, pincode=pincode, expertise_in=expertise_in,achievement=achievement, course=course, branch=branch,passing_year=passing_year)
        userdict=EmploymentDetails.objects.all()
        return render(request,'employment_info_view.html',{'userdict':userdict})



def employ_del_a(request):
    if request.method=="POST":
        id=request.POST.get('id')
        udata=EmploymentDetails.objects.get(id=id)
        udata.delete()
        userdict=EmploymentDetails.objects.all()
        return render(request,'employment_info_view_a.html',{'userdict':userdict})

def employ_update_a(request):
    if request.method=="POST":
        id=request.POST.get('id')
        userdict=EmploymentDetails.objects.filter(id=id).values()
        return render(request,'employ_edit_a.html',{'userdict':userdict})

def employ_db_a(request):
    if request.method=="POST":
        id=request.POST.get('id')
        organization = request.POST.get('t1', '')
        designation = request.POST.get('t2', '')
        address = request.POST.get('t3', '')
        country = request.POST.get('t4', '')
        pincode = request.POST.get('t5', '')
        expertise_in = request.POST.get('t6', '')
        achievement = request.POST.get('t7', '')
        course = request.POST.get('t8', '')
        branch = request.POST.get('t9', '')
        passing_year = request.POST.get('t10', '')
        EmploymentDetails.objects.filter(id=id).update(organization=organization, designation=designation,address=address, country=country, pincode=pincode, expertise_in=expertise_in,achievement=achievement, course=course, branch=branch,passing_year=passing_year)
        userdict=EmploymentDetails.objects.all()
        return render(request,'employment_info_view_a.html',{'userdict':userdict})

def search_alumni(request):
    if request.method=="POST":
        name=request.POST.get('t1')
        userdict=AlumniRegistration.objects.filter(fname=name).values()
        return render(request,'search_view.html',{'userdict':userdict})
    return render(request,'search_alumni.html')


def alumni_view(request):
    userdict=AlumniRegistration.objects.all()
    return render(request,'alumni_view.html',{'userdict':userdict})




def alumni_del(request):
    if request.method=="POST":
        id=request.POST.get('id')
        udata=AlumniRegistration.objects.get(id=id)
        udata.delete()
        userdict=AlumniRegistration.objects.all()
        return render(request,'search_view.html',{'userdict':userdict})

'''def alumni_update(request):
    if request.method == "POST":
        cid=request.POST.get('id')
        userdict=AlumniRegistration.objects.filter(id=cid).values()
        return render(request,'alumni_edit.html',{'userdict':userdict})'''

def alumni_update(request):
    if request.method == "POST":
        id=request.POST.get('id')
        userdict=AlumniRegistration.objects.filter(id=id).values()
        return render(request,'alumni_edit.html',{'userdict':userdict})


def alumni_db(request):
    if request.method=="POST":
        id=request.POST.get('id')
        fname = request.POST.get('t3', '')
        mname = request.POST.get('t4', '')
        lname = request.POST.get('t5', '')
        dob = request.POST.get('t6', '')
        email = request.POST.get('t7', '')
        mobileno = request.POST.get('t10', '')
        alumni_chapter = request.POST.get('t11', '')
        address = request.POST.get('t12', '')
        city = request.POST.get('t14', '')
        pincode = request.POST.get('t15', '')
        AlumniRegistration.objects.filter(id=id).update(fname=fname,mname=mname,lname=lname,dob=dob,email=email,mobileno=mobileno,alumni_chapter=alumni_chapter,address=address,city=city,pincode=pincode)
        userdict=AlumniRegistration.objects.all()
        return render(request,'search_view.html',{'userdict':userdict})


def edit_alumni(request):
    username=request.session['username']
    userdict=AlumniRegistration.objects.filter(logId=username).values()
    return render(request,'edit_alumni.html',{'userdict':userdict})


def alumni_db_a(request):
    if request.method=="POST":
        id=request.POST.get('id')
        fname = request.POST.get('t3', '')
        mname = request.POST.get('t4', '')
        lname = request.POST.get('t5', '')
        dob = request.POST.get('t6', '')
        email = request.POST.get('t7', '')
        mobileno = request.POST.get('t10', '')
        alumni_chapter = request.POST.get('t11', '')
        address = request.POST.get('t12', '')
        city = request.POST.get('t14', '')
        pincode = request.POST.get('t15', '')
        AlumniRegistration.objects.filter(id=id).update(fname=fname,mname=mname,lname=lname,dob=dob,email=email,mobileno=mobileno,alumni_chapter=alumni_chapter,address=address,city=city,pincode=pincode)
        userdict=AlumniRegistration.objects.all()
        return render(request,'search_view.html',{'userdict':userdict})

def chapter_wise_view(request):
    if request.method=="POST":
        chapter=request.POST.get('t1')
        userdict=AlumniRegistration.objects.filter(alumni_chapter=chapter).values()
        return render(request,'chapter_wise_view2.html',{'userdict':userdict})

    return render(request,'chapter_wise_view.html')


def add_event(request):
    if request.method=="POST":
        chapter= request.POST.get('c1', '')
        eventdate=request.POST.get('t1','')
        eventtime = request.POST.get('t2', '')
        eventname = request.POST.get('t3', '')
        venue = request.POST.get('t4', '')
        description = request.POST.get('t5', '')
        AddEvent.objects.create(eventdate=eventdate,eventtime=eventtime,eventname=eventname,venue=venue,description=description,chapter=chapter)
        return render(request,'admin_home.html')
    return render(request,'add_event.html')


def event_view(request):
    userdict=AddEvent.objects.all()
    return render(request,'event_view.html',{'userdict':userdict})

def event_view_a(request):
    userdict=AddEvent.objects.all()
    return render(request,'event_view_a.html',{'userdict':userdict})


def chapter(request):
    return render(request,'chapter.html')



def chapter_blore(request):
    userdict=AlumniRegistration.objects.filter(alumni_chapter='Banglore Chapter').values()
    udict = AddEvent.objects.filter(chapter='Banglore Chapter').values()
    return render(request,'chapter_wise_view1.html',{'userdict':userdict,'udict':udict})

def chapter_belgaum(request):
    userdict=AlumniRegistration.objects.filter(alumni_chapter='Belgum Chapter').values()
    udict = AddEvent.objects.filter(chapter='Belgum Chapter').values()
    return render(request,'chapter_wise_view22.html',{'userdict':userdict,'udict':udict})

def chapter_bvb(request):
    userdict=AlumniRegistration.objects.filter(alumni_chapter='BVB Alumni Association, Hubli').values()
    udict = AddEvent.objects.filter(chapter='BVB Alumni Association, Hubli').values()
    return render(request,'chapter_wise_view3.html',{'userdict':userdict,'udict':udict})

def chapter_pune(request):
    userdict=AlumniRegistration.objects.filter(alumni_chapter='Pune Chapter').values()
    udict = AddEvent.objects.filter(chapter='Pune Chapter').values()
    return render(request,'chapter_wise_view4.html',{'userdict':userdict,'udict':udict})


def forgotpass(request):
    if request.method=="POST":
        uname=request.POST.get('t1','')
        ucheck=UserLogin.objects.filter(username=uname).count()
        if ucheck>= 1:
            udata=UserLogin.objects.filter(username=uname).values()
            for a in udata:
                password="Your Password Is:"+" "+a['password']
                return render(request,'login2.html',{'msg':password})
        else:
            return render(request,'forgotpass.html',{'msg':'Invalid Username'})
    return render(request,'forgotpass.html')

def send_mail(request,pk):
    dd=AddEvent.objects.get(id=pk)
    chapter=dd.chapter
    eventname=dd.eventname
    edate=dd.eventdate
    venue=dd.venue
    udata=AlumniRegistration.objects.filter(alumni_chapter=chapter).values()
    return render(request,'send_mail.html',{'udata':udata,'ename':eventname,'edate':edate, 'venue':venue})

def send_mail_alumni(request):
    userdict = AddEvent.objects.all()
    if request.method=="POST":
        email=request.POST.get('c1')
        ename=request.POST.get('t1')
        edate = request.POST.get('t2')
        venue=request.POST.get('t4')
        #content = "On this date:"+edate+"You have this event:"+ename
        content = "Respected alumni, KLE Techonological University is organizing an event "+ename+" on "+str(edate)+ " at "+str(venue)+". So we kindly request the honor of your presence."
        mail = smtplib.SMTP('smtp.gmail.com', 587)
        mail.ehlo()
        mail.starttls()
        mail.login('vishalenterprisers11@gmail.com', 'Vishal@11')
        mail.sendmail('vishalenterprisers11@gmail.com',email, content)
        mail.close()

        return render(request,'event_view.html',{'userdict':userdict})

def gallery(request):
    return render(request,'gallery.html')